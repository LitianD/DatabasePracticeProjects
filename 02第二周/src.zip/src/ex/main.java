package ex;

import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import javax.swing.JTextField;
import java.awt.Button;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Label;
import java.awt.TextField;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;

import ex.Frame;
import ex.MMU;
import ex.Page;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JComboBox;

public class main {
	Frame frames;
	MMU mmu = new MMU("TheLittlePrince.txt");;

	private JFrame frame;
	private JTextField textField;
	private String message[] = new String[50000];
	JComboBox comboBox;
	TextField textField_1;
	JTextArea textArea_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main window = new main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 658, 483);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		try{
			Image img = ImageIO.read(frame.getClass().getResource("/Img/pirture.png"));
			frame.setIconImage(img);
			//����ͼ��
		}catch(IOException e){
			e.printStackTrace();
		}

		textField_1 = new TextField();
		textField_1.setBounds(202, 82, 411, 25);
		frame.getContentPane().add(textField_1);
		
		JButton btnPages = new JButton("Read");
		btnPages.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Object o = comboBox.getSelectedItem();
				String mes = (String) o;
				textArea_1 = new JTextArea();
				textArea_1.setBounds(14, 120, 612, 288);
				frame.getContentPane().add(textArea_1);
				try {
					textArea_1.setText(mmu.getPage(Integer.parseInt(mes)));
					String str="�����";
					for(int i = 0;i < mmu.pagesArray.size();i++)
					{
						str = str +Integer.toString(mmu.pagesArray.get(i)) +",";
					}
					textField_1.setText(str);
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		btnPages.setBounds(186, 33, 80, 27);
		frame.getContentPane().add(btnPages);
		
		JButton btnNewButton = new JButton("save");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

			}
		});
		btnNewButton.setBounds(268, 33, 80, 27);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("add a page");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		btnNewButton_1.setBounds(362, 33, 124, 27);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("open file");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mmu = new MMU("TheLittlePrince.txt");
				JOptionPane.showMessageDialog(null,"��ȡ�ɹ���");
				for(int i = 0;i < mmu.pages.size();i++)
					message[i] = String.valueOf(i+1);
				comboBox = new JComboBox(message);
				comboBox.setBounds(53, 34, 91, 24);
				frame.getContentPane().add(comboBox);
			}
		});
		btnNewButton_2.setBounds(500, 33, 113, 27);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblPages = new JLabel("page");
		lblPages.setBounds(14, 37, 52, 18);
		frame.getContentPane().add(lblPages);
		
		JLabel lblNewLabel = new JLabel("pages number in memory");
		lblNewLabel.setBounds(14, 89, 188, 18);
		frame.getContentPane().add(lblNewLabel);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(24, 118, 589, 305);
		frame.getContentPane().add(textArea_1);
		

		
		
	}
}
